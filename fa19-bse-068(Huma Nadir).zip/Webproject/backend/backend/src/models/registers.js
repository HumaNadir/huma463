const mongoose = require("mongoose");
const bookingSchema = new mongoose.Schema({
    name:{
        type:String,
    },
    email:{
        type:String,
    },
    phone:{
        type:Number,
    },
    date:{
        type:Date,
    },
    comments:{
        type:String,
    }

})
//No Image Name Details Action 
//show edit delete
//create new project app.create
//app.get app.put app.delete 
//ctreate read(get) update(put) delete(delete)
//product updated successfully
//Laravel 8 Breeze Tutos
//Laravel 8 Livewire Tutus
//Laravel 8 Ajax Example tuts
//Laravel 8 form validation Tutus 
//product updated successfully 
//database connection orientation
//type:String, comments: {  }

const Register = new mongoose.model("Register", bookingSchema);

module.exports = Register;